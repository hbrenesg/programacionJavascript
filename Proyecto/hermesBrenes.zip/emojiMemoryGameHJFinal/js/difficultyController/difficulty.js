export class Difficulty {
    constructor() { }
}