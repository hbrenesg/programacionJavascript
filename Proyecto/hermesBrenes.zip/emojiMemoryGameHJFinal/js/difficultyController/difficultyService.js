export class DifficultyService {
    constructor() { }
}