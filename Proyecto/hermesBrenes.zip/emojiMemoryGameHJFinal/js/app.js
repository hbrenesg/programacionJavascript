import { GameManager } from "./gameManager.js";

window.addEventListener('load', init, false);

function init() {
    const gameManager = new GameManager();
}