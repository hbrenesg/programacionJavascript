export class LoginService {
    constructor() { }
}