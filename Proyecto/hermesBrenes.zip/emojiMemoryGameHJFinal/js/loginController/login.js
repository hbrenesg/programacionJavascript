export class Login {
    constructor() { }
}