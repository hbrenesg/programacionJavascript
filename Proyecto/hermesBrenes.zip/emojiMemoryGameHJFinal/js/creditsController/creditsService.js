export class CreditsService {
    constructor() { }
}