export class Credits {
    constructor() { }
}