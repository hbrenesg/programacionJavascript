export class MenuService {
    constructor() { }
}