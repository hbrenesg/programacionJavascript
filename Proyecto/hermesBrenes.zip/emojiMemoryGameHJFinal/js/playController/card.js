export class Card {
    constructor() { }
}