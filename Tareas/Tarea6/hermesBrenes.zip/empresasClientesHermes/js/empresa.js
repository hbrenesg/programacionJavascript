export class Empresa {
    constructor(nombre = '', cliente = null) {
        this.nombre = nombre;
        this.cliente = cliente;
    }
}